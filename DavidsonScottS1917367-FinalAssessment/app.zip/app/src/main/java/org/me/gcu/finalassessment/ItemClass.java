
        package org.me.gcu.finalassessment;


import android.util.Log;


        public class ItemClass {
    private String title;
    private String description;
    private String link;
    private String pubDate;
    private String category;
    private String geolat;
    private String geolong;
        public ItemClass()
    {
        title = "";
        description= " ";
        link = " ";
        pubDate = " ";
        category = " ";
        geolat = " ";
        geolong = " ";
    }

    public ItemClass(String atitle, String adescription, String alink, String apubDate, String acategory, String alat, String along)
    {
        title = atitle;
        description = adescription;
        link = alink;
        pubDate = apubDate;
        category = acategory;
        geolat = alat;
        geolong = along;
    }

    public String getTitle()
    {
        return title;
    }

    public void setTitle(String atitle)
    {
        title = atitle;
    }

    public String getDescription()
    {
        return description;
    }

    public void setDescription(String adescription) {
        description = adescription;
    }

    public String getLink()
    {
        return link;
    }

    public void setLink(String alink)
    {
        link = alink;
    }

    public String getPubDate()
    {
        return pubDate;
    }

    public void setPubDate(String apubdate) {
        pubDate = apubdate;
    }

    public String getCategory()
    {
        return category;
    }

    public void setCategory(String acategory)
    {
        category = acategory;
        Log.d("MyTag", "Item category Stored: " + category);
    }

    public String getLat()
    {
        return geolat;
    }

    public void setLat(String alat)
    {
        geolat = alat;
    }

    public String getLong() { return geolong; }

    public void setLong(String along)
    {
        geolong = along;
    }

    public String toString()
    {
        String temp;

        temp = title + " " + description + " " + link + " " + pubDate + " " + category + " " + geolat + " " + geolong;

        return temp;
    }

            public void getDepths()
            {
                String[] depthString = getDescription().split(";");
                String part4 = depthString[3].trim();
                String depths = part4.replaceAll("[^0-9]", "");
                Integer depth = Integer.valueOf(depths);
                if(depth > MainActivity.infoStorer.largestDepthValue)
                {
                    MainActivity.infoStorer.largestDepthValue = depth;
                    String[] data = getTitle().split(":");
                    String section2 = data[2].trim();
                    String[] locs = section2.split(", ");
                    String location = locs[0].trim();
                    MainActivity.infoStorer.largestDepth = "Largest depth location: " + location + "\n" + "Largest depth: " + MainActivity.infoStorer.largestDepthValue + "\n" + "Largest depth geo:lat: " + getLat() + "\n" + "Largest depth geo:long: " + getLong();
                }
                else
                if(MainActivity.infoStorer.smallestDepthValue > depth)
                {
                    MainActivity.infoStorer.smallestDepthValue = depth;
                    String[] data = getTitle().split(":");
                    String section2 = data[2].trim();
                    String[] locs = section2.split(", ");
                    String location = locs[0].trim();
                    MainActivity.infoStorer.smallestDepth = "Smallest depth location: " + location + "\n" + "Smallest depth: " + MainActivity.infoStorer.smallestDepthValue + "\n" + "Smallest depth geo:lat: " + getLat() + "\n" + "Smallest depth geo:long: " + getLong();
                }

            }

            public void getMagnitudes()
            {
                String[] dataString = MainActivity.item.getTitle().split(":");
                String section1 = dataString[1].trim();
                String Magnitudes = section1.replaceAll("[^0-9.]", "");
                Float magsNums = Float.valueOf(Magnitudes);
                if(magsNums > MainActivity.infoStorer.largestMagniitudeValue)
                {
                    MainActivity.infoStorer.largestMagniitudeValue = magsNums;
                    String[] data = MainActivity.item.getTitle().split(":");
                    String section2 = data[2].trim();
                    String[] locs = section2.split(", ");
                    String location = locs[0].trim();
                    MainActivity.infoStorer.largestMagnitude = "Largest Magnitude Location: " + location + "\n" + "Largest magnitude: " + MainActivity.infoStorer.largestMagniitudeValue + "\n" + "Largest Magnitude geo:lat: " + MainActivity.item.getLat() + "\n" + "Largest Magnitude geo:long: " + MainActivity.item.getLong();

                }
            }

            public Integer dateGetter()
            {
                String[] dat = getPubDate().split(",");
                String part2 = dat[1].trim();
                Log.d("Date Parts:", part2);
                String[] days = part2.split(" ");
                Integer day = Integer.parseInt(days[0]);
                Log.d("Day value", String.valueOf(day));
                return day;
            }

            public int monthGetter() {
                int pubMonth = 0;
                String[] dat = MainActivity.item.getPubDate().split(",");
                String part2 = dat[1].trim();
                Log.d("Months:", part2);
                String[] months = part2.split(" ");
                String month = months[1];
                Log.d("Monthy", month);
                if (month.equals("Jan")) {
                    pubMonth = 1;
                } else if (month.equals("Feb")) {
                    pubMonth = 2;
                } else if (month.equals("Mar")) {
                    pubMonth = 3;
                } else if (month.equals("Apr")) {
                    pubMonth = 4;
                } else if (month.equals("May")) {
                    pubMonth = 5;
                } else if (month.equals("Jun")) {
                    pubMonth = 6;
                } else if (month.equals("Jul")) {
                    pubMonth = 7;
                } else if (month.equals("Aug")) {
                    pubMonth = 8;
                } else if (month.equals("Sep")) {
                    pubMonth = 9;
                } else if (month.equals("Oct")) {
                    pubMonth = 10;
                } else if (month.equals("Nov")) {
                    pubMonth = 11;
                } else if (month.equals("Dec")) {
                    pubMonth = 12;
                }
                return pubMonth;
            }

        }